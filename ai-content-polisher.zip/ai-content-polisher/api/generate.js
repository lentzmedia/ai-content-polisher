export default async function handler(req, res) {
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Method not allowed" });
  }

  const { text, lang, tone } = req.body;

  const prompt = `
Tu reçois un texte et tu dois le transformer en 10 formats différents :
LinkedIn, TikTok, YouTube Short, Tweet, Thread, Email, Instagram caption,
Mini article, Storytelling, Version persuasive.

Texte original :
"${text}"

Langue : ${lang}
Ton : ${tone}

Retourne uniquement du JSON avec les clés suivantes :
linkedin_post, tiktok_script, youtube_short_script, tweet_single, tweet_thread,
email_professional, instagram_caption, mini_article,
storytelling_version, persuasive_marketing_version.
`;

  const response = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "x-api-key": process.env.CLAUDE_API_KEY,
      "anthropic-version": "2023-06-01",
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      model: "claude-3-5-sonnet-latest",
      max_tokens: 2500,
      messages: [
        { role: "user", content: prompt }
      ],
    }),
  });

  const json = await response.json();
  const textOutput = json.content[0].text;

  const match = textOutput.match(/\{[\s\S]*\}/);
  const result = match ? JSON.parse(match[0]) : { raw: textOutput };

  res.status(200).json(result);
}
